# Microschool

A personal learning project for understanding how a microschool learning platform can work.

This project is inspired by general microschool concepts such as:

- small learning communities
- learner-centered progress
- guides/mentors
- individualized learning
- parent visibility
- curriculum and progress tracking

It is not an implementation or reproduction of any proprietary platform.


## Architecture

Frontend:

- HTML
- CSS
- JavaScript

Backend:

- Python
- FastAPI
- SQLAlchemy
- SQLite

Authentication:

- JWT


## Setup

Run:

    ./scripts/create-files.sh

Then:

    ./scripts/fill-files.sh

Then:

    ./run.sh


Open:

    http://127.0.0.1:8000

API documentation:

    http://127.0.0.1:8000/docs


## Development Roadmap

Phase 1:

- users
- roles
- pods
- courses
- lessons
- progress

Phase 2:

- authentication
- dashboards
- assignments
- quizzes
- attendance

Phase 3:

- parent accounts
- learner goals
- notifications
- guide notes

Phase 4:

- individualized learning paths
- analytics
- mastery tracking
- recommendation engine

Phase 5:

- PostgreSQL
- Docker
- production deployment
